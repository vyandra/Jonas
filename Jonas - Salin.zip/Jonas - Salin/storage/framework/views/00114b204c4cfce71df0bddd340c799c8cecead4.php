<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag/dist/css/multi-select-tag.css">

<h1>Edit Student</h1>

<form action="<?php echo e(route('students.update', ['student' => $student->id])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="form-group">
        <label for="sekolah">Sekolah:</label>
        <input type="text" id="sekolah" name="sekolah" value="<?php echo e($student->sekolah); ?>" class="form-control">
    </div>

    <div class="form-group">
        <label for="alamat">Alamat:</label>
        <input type="text" id="alamat" name="alamat" value="<?php echo e($student->alamat); ?>" class="form-control">
    </div>
    <select name="jurusans[]"  id="jurusan" class="form-input" multiple required>
    <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($jurusan->id); ?>" <?php echo e(in_array($jurusan->id, $student->jurusans->pluck('id')->toArray()) ? 'selected' : ''); ?>><?php echo e($jurusan->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<script src="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag/dist/js/multi-select-tag.js"></script>

<script>
    new MultiSelectTag('jurusan')  // id
</script>
<br>

    <div class="form-group">
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-default">Cancel</a>
    </div>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jonas\Jonas - Salin\resources\views/admin/edit.blade.php ENDPATH**/ ?>