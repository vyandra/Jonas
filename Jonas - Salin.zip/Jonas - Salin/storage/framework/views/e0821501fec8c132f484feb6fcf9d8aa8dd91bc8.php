<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard">
          <i class="mdi mdi-home menu-icon" style="margin-right: -0px; margin-top: -5px;"></i>
          <span class="menu-title">Master Sekolah</span>
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="master_karyawan">
          <i class="mdi mdi-account-card-details" style="margin-right: 5px;"></i>
          <span class="menu-title">Master Karyawan</span>
        </a>
      </li>
     
    </ul>
  </nav>
<?php /**PATH C:\Users\Jonas\Jonas - Salin\resources\views/layouts/inc/admin/sidebar.blade.php ENDPATH**/ ?>