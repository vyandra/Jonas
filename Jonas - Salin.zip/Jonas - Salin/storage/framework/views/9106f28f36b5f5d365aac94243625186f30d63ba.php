

<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag/dist/css/multi-select-tag.css">

<div class="container">
    <h2>Edit Page</h2>
    <form action="<?php echo e(route('dashboard.updateFile', $file->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <!-- File Details -->
        <div class="form-group row">
            <div class="col-md-6">
                <label for="nama" class="col-form-label">Nama:</label>
                <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e($file->nama); ?>">
            </div>
            <div class="col-md-6">
    <label for="student_id" class="col-form-label">Sekolah/Universitas:</label>
    <select name="student_id" id="student_id" class="form-control" style="color: #252525; height: 45px;"> 
    <option value="" style="color: #252525;">Select Sekolah</option>
        <?php $__currentLoopData = $studentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($student->id); ?>" style="color: #252525;"><?php echo e($student->sekolah); ?></option>
                <?php echo e($student->sekolah); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>
            <div class="form-group row">
            <div class="col-md-6">
    <label for="jurusan" class="col-form-label">Jurusan:</label>
    <select multiple name="jurusan[]" id="jurusan" class="form-control">
        <?php $__currentLoopData = $jurusans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($jurusan->id); ?>" <?php echo e(in_array($jurusan->id, $selectedJurusans) ? 'selected' : ''); ?>>
                <?php echo e($jurusan->name); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

            <script src="https://cdn.jsdelivr.net/gh/habibmhamadi/multi-select-tag/dist/js/multi-select-tag.js"></script>

<script>
    new MultiSelectTag('jurusan')  // id
</script>
       
            <div class="col-md-6">
                <label for="tempat" class="col-form-label">Tempat Lahir:</label>
                <input type="text" name="tempat" id="tempat" class="form-control" value="<?php echo e($file->tempat); ?>">
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-6">
                <label for="tgl_lahir" class="col-form-label">Tanggal Lahir:</label>
                <input type="text" name="tgl_lahir" id="tgl_lahir" class="form-control" value="<?php echo e($file->tgl_lahir); ?>">
            </div>
            <div class="col-md-6">
                <label for="posisi" class="col-form-label">Posisi:</label>
                <input type="text" name="posisi" id="posisi" class="form-control" value="<?php echo e($file->posisi); ?>">
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-6">
                <label for="tgl_join" class="col-form-label">Tanggal Join:</label>
                <input type="date" name="tgl_join" id="tgl_join" class="form-control" value="<?php echo e($file->tgl_join); ?>">
            </div>
            <div class="col-md-6">
                <label for="tgl_keluar" class="col-form-label">Tanggal Keluar:</label>
                <input type="date" name="tgl_keluar" id="tgl_keluar" class="form-control" value="<?php echo e($file->tgl_keluar); ?>">
            </div>
        </div>
        <div class="form-group row">
            <div class="col-md-6">
                <label for="alasan_keluar" class="col-form-label">Alasan Keluar:</label>
                <input type="text" name="alasan_keluar" id="alasan_keluar" class="form-control" value="<?php echo e($file->alasan_keluar); ?>">
            </div>
        </div>
        
        <!-- File Upload -->
        <div class="form-group row">
            <div class="col-md-12">
                <label for="new_file" class="col-form-label">Upload New File:</label>
                <input type="file" name="new_file" id="new_file" accept=".doc, .docx, .pdf" class="form-control">
            </div>
        </div>
        
        <div class="form-group row">
            <div class="col-md-12">
                <button type="submit" class="btn btn-primary">Save Changes</button>
                <a href="<?php echo e(route('admin.master_karyawan')); ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jonas\Jonas - Salin\resources\views/admin/edit_file.blade.php ENDPATH**/ ?>