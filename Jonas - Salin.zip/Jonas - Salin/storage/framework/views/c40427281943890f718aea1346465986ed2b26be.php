

<?php $__env->startSection('content'); ?>
<div>
    <h1>File Details</h1>
    <iframe src="<?php echo e($fileUrl); ?>" width="100%" height="500px"></iframe>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jonas\Jonas - Salin\resources\views/admin/pdf-viewer.blade.php ENDPATH**/ ?>